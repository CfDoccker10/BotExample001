﻿using System;
using System.Threading.Tasks;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;

namespace Bot_Application3.Dialogs
{
    [Serializable]
    public class RootDialog : IDialog<object>
    {
        public Task StartAsync(IDialogContext context)
        {
            context.Wait(MessageReceivedAsync);

            return Task.CompletedTask;
        }

        private async Task MessageReceivedAsync(IDialogContext context, IAwaitable<object> result)
        {
            var activity = await result as Activity;

            // calculate something for us to return
            int length = (activity.Text ?? string.Empty).Length;
            string languageDeinition = "I cannot find information on that programming language in my data collection, it is limited at this time and does not include all programming languages. In a real bot as a tool this information would be pulled from the internet to show complete information on all programming languages.";

            // return our reply to the user
            // ========================================================================
            // In a real applicatoin this would pull the information from the internet
            // ========================================================================
            switch (activity.Text.Trim().ToLower())
            {
                case "c#":
                    languageDeinition = "C# is a hybrid of C and C++, it is a Microsoft programming language developed to compete with Sun's Java language. C# is an object-oriented programming language used with XML-based Web services on the .NET platform and designed for improving productivity in the development of Web applications.";
                    break;
                case "javascript":
                    languageDeinition = 
                        @"JavaScript is a programming language commonly used in web development. It was originally developed by Netscape as a means to add dynamic and interactive elements to websites. While JavaScript is influenced by Java, the syntax is more similar to C and is based on ECMAScript, a scripting language developed by Sun Microsystems."
                        +
                        @"  JavaScript is a client - side scripting language, which means the source code is processed by the client's web browser rather than on the web server. This means JavaScript functions can run after a webpage has loaded without communicating with the server. For example, a JavaScript function may check a web form before it is submitted to make sure all the required fields have been filled out. The JavaScript code can produce an error message before any information is actually transmitted to the server."
                        +
                        @"  Like server-side scripting languages, such as PHP and ASP, JavaScript code can be inserted anywhere within the HTML of a webpage.However, only the output of server - side code is displayed in the HTML, while JavaScript code remains fully visible in the source of the webpage.It can also be referenced in a separate .JS file, which may also be viewed in a browser.";
                    break;
                case "java": 
                    languageDeinition =
                        @"Java is a general-purpose computer-programming language that is concurrent, class-based, object-oriented, and specifically designed to have as few implementation dependencies as possible. It is intended to let application developers ""write once, run anywhere"" (WORA), meaning that compiled Java code can run on all platforms that support Java without the need for recompilation.[17] Java applications are typically compiled to bytecode that can run on any Java virtual machine (JVM) regardless of computer architecture. As of 2016, Java is one of the most popular programming languages in use, particularly for client-server web applications, with a reported 9 million developers.[22] Java was originally developed by James Gosling at Sun Microsystems (which has since been acquired by Oracle Corporation) and released in 1995 as a core component of Sun Microsystems' Java platform. The language derives much of its syntax from C and C++, but it has fewer low-level facilities than either of them."
                        +
                        @"  The original and reference implementation Java compilers, virtual machines, and class libraries were originally released by Sun under proprietary licenses.As of May 2007, in compliance with the specifications of the Java Community Process, Sun relicensed most of its Java technologies under the GNU General Public License.Others have also developed alternative implementations of these Sun technologies, such as the GNU Compiler for Java (bytecode compiler), GNU Classpath (standard libraries), and IcedTea-Web (browser plugin for applets)."
                        +
                        @"  The latest version is Java 10, released on March 20, 2018, which follows Java 9 after only six months[24] in line with the new release schedule.Java 8 is still supported but there will be no more security updates for Java 9.[25] Versions earlier than Java 8 are supported by companies on a commercial basis; e.g.by Oracle back to Java 6 as of October 2017 (while they still ""highly recommend that you uninstall"" pre-Java 8 from at least Windows computers).";
                    break;
                case "c":
                    languageDeinition =
                        @"The C Programming Language (sometimes termed K&R, after its authors' initials) is a computer programming book written by Brian Kernighan and Dennis Ritchie, the latter of whom originally designed and implemented the language, as well as co-designed the Unix operating system with which development of the language was closely intertwined. The book was central to the development and popularization of the C programming language and is still widely read and used today. Because the book was co-authored by the original language designer, and because the first edition of the book served for many years as the de facto standard for the language, the book was regarded by many to be the authoritative reference on C"
                        + 
                        @"  The first edition of the book, published in 1978, was the first widely available book on the C programming language. C was created by Dennis Ritchie. Brian Kernighan wrote the first C tutorial. The authors came together to write the book in conjunction with the language's early development at AT&T Bell Labs. The version of C described in this book is sometimes termed K&R C (after the book's authors), often to distinguish this early version from the later version of C standardized as ANSI C."
                        +
                        @"  In 1988, the second edition of the book was published, updated to cover the changes to the language resulting from the then-new ANSI C standard, particularly with the inclusion of reference material on standard libraries. The second edition (and as of 2018, the most recent edition) of the book has since been translated into over 20 languages. In 2012, an eBook version of the second edition was published in ePub, Mobi, and PDF formats."
                        +
                        @"  ANSI C, first standardized in 1989 (as ANSI X3.159-1989), has since undergone several revisions, the most recent of which is ISO/IEC 9899:2011 (also termed C11), adopted as an ANSI standard in October 2011. However, no new edition of The C Programming Language has been issued to cover the more recent standards.";
                    break;
                case "sql":
                    languageDeinition =
                        @"SQL 'sequel'; Structured Query Language) is a domain-specific language used in programming and designed for managing data held in a relational database management system (RDBMS), or for stream processing in a relational data stream management system (RDSMS). In comparison to older read/write APIs like ISAM or VSAM, SQL offers two main advantages: first, it introduced the concept of accessing many records with one single command; and second, it eliminates the need to specify how to reach a record, e.g. with or without an index."
                        +
                        @"  Originally based upon relational algebra and tuple relational calculus, SQL consists of many types of statements, which may be informally classed as sublanguages, commonly: a data query language(DQL), a data definition language(DDL),[b] a data control language(DCL), and a data manipulation language(DML). The scope of SQL includes data query, data manipulation(insert, update and delete), data definition(schema creation and modification), and data access control.Although SQL is often described as, and to a great extent is, a declarative language (4GL), it also includes procedural elements."
                        +
                        @"  SQL was one of the first commercial languages for Edgar F.Codd's relational model, as described in his influential 1970 paper, A Relational Model of Data for Large Shared Data Banks. Despite not entirely adhering to the relational model as described by Codd, it became the most widely used database language."
                        +
                        @"  SQL became a standard of the American National Standards Institute (ANSI) in 1986, and of the International Organization for Standardization (ISO) in 1987. Since then, the standard has been revised to include a larger set of features. Despite the existence of such standards, most SQL code is not completely portable among different database systems without adjustments.";
                    break;
                case "ruby":
                    languageDeinition =
                    @"Ruby is a dynamic, reflective, object-oriented, general-purpose programming language. It was designed and developed in the mid-1990s by Yukihiro ""Matz"" Matsumoto in Japan."
                    +
                    @"  According to the creator, Ruby was influenced by Perl, Smalltalk, Eiffel, Ada, and Lisp.It supports multiple programming paradigms, including functional, object-oriented, and imperative. It also has a dynamic type system and automatic memory management.";
                    break;
                case "visual basic":
                    languageDeinition =
                        @"Visual Basic is a third-generation event-driven programming language and integrated development environment (IDE) from Microsoft for its Component Object Model (COM) programming model first released in 1991 and declared legacy during 2008. Microsoft intended Visual Basic to be relatively easy to learn and use. Visual Basic was derived from BASIC and enables the rapid application development (RAD) of graphical user interface (GUI) applications, access to databases using Data Access Objects, Remote Data Objects, or ActiveX Data Objects, and creation of ActiveX controls and objects."
                        +
                        @"  A programmer can create an application using the components provided by the Visual Basic program itself. Over time the community of programmers developed third-party components. Programs written in Visual Basic can also use the Windows API, which requires external function declarations."
                        +
                        @"  The final release was version 6 in 1998 (now known simply as Visual Basic). On April 8, 2008, Microsoft stopped supporting Visual Basic 6.0 IDE. The Microsoft Visual Basic team still maintains compatibility for Visual Basic 6.0 applications on Windows Vista, Windows Server 2008 including R2, Windows 7, Windows 8, Windows 8.1, Windows Server 2012 and Windows 10 through its ""It Just Works"" program. In 2014, some software developers still preferred Visual Basic 6.0 over its successor, Visual Basic .NET. In 2014 some developers lobbied for a new version of Visual Basic 6.0. In 2016, Visual Basic 6.0 won the technical impact award at The 19th Annual D.I.C.E. Awards. A dialect of Visual Basic, Visual Basic for Applications (VBA), is used as a macro or scripting language within several Microsoft applications, including Microsoft Office.";
                    break;
                case "visual basic .net":
                    languageDeinition =
                        @"Visual Basic .NET (VB.NET) is a multi-paradigm, object-oriented programming language, implemented on the .NET Framework. Microsoft launched VB.NET in 2002 as the successor to its original Visual Basic language. Although the "".NET"" portion of the name was dropped in 2005, this article uses ""Visual Basic .NET"" to refer to all Visual Basic languages releases since 2002, in order to distinguish between them and the classic Visual Basic. Along with Visual C#, it is one of the two main languages targeting the .NET framework."
                        +
                        @"  Microsoft's integrated development environment (IDE) for developing in Visual Basic .NET language is Visual Studio. Most Visual Studio editions are commercial; the only exceptions are Visual Studio Express and Visual Studio Community, which are freeware. In addition, the .NET Framework SDK includes a freeware command-line compiler called vbc.exe. Mono also includes a command-line VB.NET compiler.";
                    break;
                case "vb script":
                    languageDeinition =
                        @"VBScript (""Microsoft Visual Basic Scripting Edition"") is an Active Scripting language developed by Microsoft that is modeled on Visual Basic. It allows Microsoft Windows system administrators to generate powerful tools for managing computers with error handling, subroutines, and other advanced programming constructs. It can give the user complete control over many aspects of their computing environment."
                        +
                        @"VBScript uses the Component Object Model to access elements of the environment within which it is running; for example, the FileSystemObject(FSO) is used to create, read, update and delete files.VBScript has been installed by default in every desktop release of Microsoft Windows since Windows 98; in Windows Server since Windows NT 4.0 Option Pack; and optionally with Windows CE(depending on the device it is installed on)."
                        +
                        @"A VBScript script must be executed within a host environment, of which there are several provided with Microsoft Windows, including: Windows Script Host(WSH), Internet Explorer(IE), and Internet Information Services(IIS).[3] Additionally, the VBScript hosting environment is embeddable in other programs, through technologies such as the Microsoft Script Control(msscript.ocx).";
                    break;
                case "c++":
                    languageDeinition =
                        @"C++ (/ˌsiːˌplʌsˈplʌs/ ""cee plus plus"") is a general-purpose programming language. It has imperative, object-oriented and generic programming features, while also providing facilities for low-level memory manipulation."
                        +
                        @"  It was designed with a bias toward system programming and embedded, resource-constrained and large systems, with performance, efficiency and flexibility of use as its design highlights. C++ has also been found useful in many other contexts, with key strengths being software infrastructure and resource-constrained applications, including desktop applications, servers (e.g. e-commerce, web search or SQL servers), and performance-critical applications (e.g. telephone switches or space probes). C++ is a compiled language, with implementations of it available on many platforms. Many vendors provide C++ compilers, including the Free Software Foundation, Microsoft, Intel, and IBM."
                        +
                        @"  C++ is standardized by the International Organization for Standardization (ISO), with the latest standard version ratified and published by ISO in December 2017 as ISO/IEC 14882:2017 (informally known as C++17). The C++ programming language was initially standardized in 1998 as ISO/IEC 14882:1998, which was then amended by the C++03, C++11 and C++14 standards. The current C++17 standard supersedes these with new features and an enlarged standard library. Before the initial standardization in 1998, C++ was developed by Bjarne Stroustrup at Bell Labs since 1979, as an extension of the C language as he wanted an efficient and flexible language similar to C, which also provided high-level features for program organization. C++20 is the next planned standard thereafter."
                        +
                        @"  Many other programming languages have been influenced by C++, including C#, D, Java, and newer versions of C.";
                    break;
                case "php":
                    languageDeinition =
                        @"PHP: Hypertext Preprocessor (or simply PHP) is a server-side scripting language designed for web development but also used as a general-purpose programming language. It was originally created by Rasmus Lerdorf in 1994, the PHP reference implementation is now produced by The PHP Group. PHP originally stood for Personal Home Page, but it now stands for the recursive acronym PHP: Hypertext Preprocessor."
                        +
                        @"  PHP code may be embedded into HTML code, or it can be used in combination with various web template systems, web content management systems, and web frameworks. PHP code is usually processed by a PHP interpreter implemented as a module in the web server or as a Common Gateway Interface (CGI) executable. The web server combines the results of the interpreted and executed PHP code, which may be any type of data, including images, with the generated web page. PHP code may also be executed with a command-line interface (CLI) and can be used to implement standalone graphical applications."
                        +
                        @"  The standard PHP interpreter, powered by the Zend Engine, is free software released under the PHP License. PHP has been widely ported and can be deployed on most web servers on almost every operating system and platform, free of charge."
                        +
                        @"  The PHP language evolved without a written formal specification or standard until 2014, leaving the canonical PHP interpreter as a de facto standard. Since 2014 work has gone on to create a formal PHP specification."
                        +
                        @"  During the 2010s there have been increased efforts towards standardisation and code sharing in PHP applications by projects such as PHP-FIG in the form of PSR-initiatives as well as Composer dependency manager and the Packagist repository. PHP hosts a diverse array of web frameworks requiring framework-specific knowledge, with Laravel recently emerging as a popular option by incorporating ideas made popular from other competing non-PHP web frameworks, like Ruby on Rails.";
                    break;
                case "phython":
                    languageDeinition =
                        @"Python is an interpreted high-level programming language for general-purpose programming. Created by Guido van Rossum and first released in 1991, Python has a design philosophy that emphasizes code readability, notably using significant whitespace. It provides constructs that enable clear programming on both small and large scales."
                        +
                        @"  Python features a dynamic type system and automatic memory management. It supports multiple programming paradigms, including object-oriented, imperative, functional and procedural, and has a large and comprehensive standard library."
                        +
                        @"  Python interpreters are available for many operating systems. CPython, the reference implementation of Python, is open source software[28] and has a community-based development model, as do nearly all of its variant implementations. CPython is managed by the non-profit Python Software Foundation.";
                    break;
                case "actionscript":
                    languageDeinition =
                        @"ActionScript is an object-oriented programming language originally developed by Macromedia Inc. (later acquired by Adobe Systems). It is a derivation of HyperTalk, the scripting language for HyperCard.[2] It is now a dialect of ECMAScript (meaning it is a superset of the syntax and semantics of the language more widely known as JavaScript), though it originally arose as a sibling, both being influenced by HyperTalk."
                        +
                        @"  ActionScript is used primarily for the development of websites and software targeting the Adobe Flash Player platform, used on Web pages in the form of embedded SWF files."
                        +
                        @"  ActionScript 3 is also used with Adobe AIR system for the development of desktop and mobile applications. The language itself is open-source in that its specification is offered free of charge[3] and both an open source compiler (as part of Apache Flex) and open source virtual machine (Mozilla Tamarin) are available."
                        +
                        @"  ActionScript is also used with Scaleform GFx for the development of 3D video game user interfaces and HUDs.";
                    break;
                case "applescript":
                    languageDeinition =
                        @"AppleScript is a scripting language created by Apple Inc. that facilitates automated control over scriptable Mac applications. First introduced in System 7, it is currently included in all versions of macOS as part of a package of system automation tools.[2][3] The term ""AppleScript"" may refer to the language itself, to an individual script written in the language, or, informally, to the macOS Open Scripting Architecture that underlies the language";
                    break;
                case "a# .Net":
                    languageDeinition = 
                        @"A# is a port of the Ada programming language to the Microsoft .NET platform. A# is freely distributed by the Department of Computer Science at the United States Air Force Academy as a service to the Ada community under the terms of the GNU General Public License."
                        +
                        @"AdaCore has taken over this development, and announced ""GNAT for .NET"", which is a fully supported.NET product with all of the features of A# and more";
                    break;
                case "cobol":
                    languageDeinition =
                        @"COBOL (/ˈkoʊbɒl, -bɔːl/; an acronym for ""common business-oriented language"") is a compiled English-like computer programming language designed for business use. It is imperative, procedural and, since 2002, object-oriented. COBOL is primarily used in business, finance, and administrative systems for companies and governments. COBOL is still widely used in legacy applications deployed on mainframe computers, such as large-scale batch and transaction processing jobs. But due to its declining popularity and the retirement of experienced COBOL programmers, programs are being migrated to new platforms, rewritten in modern languages or replaced with software packages. Most programming in COBOL is now purely to maintain existing applications."
                        +
                        @"   COBOL was designed in 1959 by CODASYL and was partly based on previous programming language design work by Grace Hopper, commonly referred to as ""the (grand)mother of COBOL"". It was created as part of a US Department of Defense effort to create a portable programming language for data processing. Intended as a stopgap, the Department of Defense promptly forced computer manufacturers to provide it, resulting in its widespread adoption. It was standardized in 1968 and has since been revised four times. Expansions include support for structured and object-oriented programming. The current standard is ISO/IEC 1989:2014."
                        +
                        @"   COBOL statements have an English-like syntax, which were designed to be self-documenting and highly readable. However, it is verbose and uses over 300 reserved words. In contrast with modern, succinct syntax like y = x;, COBOL has a more English-like syntax (in this case, MOVE x TO y). COBOL code is split into four divisions (identification, environment, data and procedure) containing a rigid hierarchy of sections, paragraphs and sentences. Lacking a large standard library, the standard specifies 43 statements, 87 functions and just one class."
                        +
                        @"   Academic computer scientists were generally uninterested in business applications when COBOL was created and were not involved in its design; it was (effectively) designed from the ground up as a computer language for business, with an emphasis on inputs and outputs, whose only data types were numbers and strings of text. COBOL has been criticized throughout its life, however, for its verbosity, design process and poor support for structured programming. These weaknesses result in monolithic and, though intended to be English-like, largely incomprehensible programs with high redundancy.";
                    break;
                case "algol":
                    languageDeinition =
                        @"ALGOL (/ˈælɡɒl, -ɡɔːl/; short for ""Algorithmic Language"") is a family of imperative computer programming languages, originally developed in the mid-1950s, which greatly influenced many other languages and was the standard method for algorithm description used by the ACM in textbooks and academic sources for more than thirty years."
                        +
                        @"   In the sense that the syntax of most modern languages is ""Algol-like"", it was arguably the most influential of the four high-level programming languages among which it was roughly contemporary: FORTRAN, Lisp, and COBOL. It was designed to avoid some of the perceived problems with FORTRAN and eventually gave rise to many other programming languages, including PL/I, Simula, BCPL, B, Pascal, and C."
                        +
                        @"  ALGOL introduced code blocks and the begin…end pairs for delimiting them. It was also the first language implementing nested function definitions with lexical scope. Moreover, it was the first programming language which gave detailed attention to formal language definition and through the Algol 60 Report introduced Backus–Naur form, a principal formal grammar notation for language design."
                        +
                        @"  There were three major specifications, named after the year they were first published:"
                        +
                        @"  ALGOL 58 – originally proposed to be called IAL, for International Algebraic Language."
                        +
                        @"  ALGOL 60 – first implemented as X1 ALGOL 60 in mid-1960. Revised 1963."
                        +
                        @"  ALGOL 68 – introduced new elements including flexible arrays, slices, parallelism, operator identification. Revised 1973."
                        +
                        @"  Niklaus Wirth based his own ALGOL W on ALGOL 60 before developing Pascal. ALGOL-W was based on the proposal for the next generation ALGOL, but the ALGOL 68 committee decided on a design that was more complex and advanced, rather than a cleaned, simplified ALGOL 60."
                        +
                        @"  ALGOL 68 is substantially different from ALGOL 60 and was not well received, so that in general ""Algol"" means ALGOL 60 and dialects thereof.";
                    break;
                case "basic":
                    languageDeinition =
                        @"BASIC (an acronym for Beginner's All-purpose Symbolic Instruction Code)[2] is a family of general-purpose, high-level programming languages whose design philosophy emphasizes ease of use. In 1964, John G. Kemeny, Thomas E. Kurtz and Mary Kenneth Keller designed the original BASIC language at Dartmouth College in New Hampshire, United States. They wanted to enable students in fields other than science and mathematics to use computers. At the time, nearly all use of computers required writing custom software, which was something only scientists and mathematicians tended to learn."
                        +
                        @"  Versions of BASIC became widespread on microcomputers in the mid-1970s and 1980s. Microcomputers usually shipped with BASIC, often in the machine's firmware. Having an easy-to-learn language on these early personal computers allowed small business owners, professionals, hobbyists, and consultants to develop custom software on computers they could afford.[original research?] In the 2010s, BASIC was popular in many computing dialects and in new languages influenced by BASIC, such as Microsoft's Visual Basic.";
                    break;
                case "coffeescript":
                    languageDeinition =
                        @"CoffeeScript is a programming language that transcompiles to JavaScript. It adds syntactic sugar inspired by Ruby, Python and Haskell in an effort to enhance JavaScript's brevity and readability. Specific additional features include list comprehension and pattern matching."
                        +
                        "   CoffeeScript support is included in Ruby on Rails version 3.1 and Play Framework. In 2011, Brendan Eich referenced CoffeeScript as an influence on his thoughts about the future of JavaScript.";
                    break;
                case "bash":
                    languageDeinition =
                        @"Bash is a Unix shell and command language written by Brian Fox for the GNU Project as a free software replacement for the Bourne shell. First released in 1989, it has been distributed widely as the default login shell for most Linux distributions and Apple's macOS (formerly OS X). A version is also available for Windows 10."
                        +
                        @"  Bash is a command processor that typically runs in a text window, where the user types commands that cause actions. Bash can also read and execute commands from a file, called a shell script. Like all Unix shells, it supports filename globbing (wildcard matching), piping, here documents, command substitution, variables, and control structures for condition-testing and iteration. The keywords, syntax and other basic features of the language are all copied from sh. Other features, e.g., history, are copied from csh and ksh. Bash is a POSIX-compliant shell, but with a number of extensions."
                        +
                        @"  The shell's name is an acronym for Bourne-again shell, a pun on the name of the Bourne shell that it replaces and on the common term ""born again""."
                        +
                        @"  A security hole in Bash dating from version 1.03 (August 1989), dubbed Shellshock, was discovered in early September 2014 and quickly led to a range of attacks across the Internet. Patches to fix the bugs were made available soon after the bugs were identified, but not all computers have been updated.";
                    break;
                case "a#":
                    languageDeinition =
                        @"A# is a port of the Ada programming language to the Microsoft .NET platform. A# is freely distributed by the Department of Computer Science at the United States Air Force Academy as a service to the Ada community under the terms of the GNU General Public License."
                        +
                        @"  AdaCore has taken over this development, and announced ""GNAT for .NET"", which is a fully supported .NET product with all of the features of A# and more.";
                    break;
                case "assembly":
                    languageDeinition =
                        @"An assembly (or assembler) language, often abbreviated asm, is a low-level programming language for a computer, or other programmable device, in which there is a very strong (but often not one-to-one) correspondence between the language and the architecture's machine code instructions. Each assembly language is specific to a particular computer architecture. In contrast, most high-level programming languages are generally portable across multiple architectures but require interpreting or compiling. Assembly language may also be called symbolic machine code."
                        +
                        @"  Assembly language is converted into executable machine code by a utility program referred to as an assembler. The conversion process is referred to as assembly, or assembling the source code. Assembly time is the computational step where an assembler is run."
                        +
                        @"  Assembly language uses a mnemonic to represent each low-level machine instruction or opcode, typically also each architectural register, flag, etc. Many operations require one or more operands in order to form a complete instruction. Most assemblers can take expressions of numbers, named constants, registers, and labels as operands. Thus, the programmers are freed from tedious repetitive calculations. Depending on the architecture, these elements may also be combined for specific instructions or addressing modes using offsets or other data as well as fixed addresses. Many assemblers offer additional mechanisms to facilitate program development, to control the assembly process, and to aid debugging.";
                    break;
                case "f#":
                    languageDeinition =
                        @"F# (pronounced F sharp) is a strongly typed, multi-paradigm programming language that encompasses functional, imperative, and object-oriented programming methods. F# is most often used as a cross-platform Common Language Infrastructure (CLI) language, but it can also generate JavaScript and graphics processing unit (GPU) code."
                        +
                        @"  F# is developed by the F# Software Foundation, Microsoft and open contributors. An open source, cross-platform compiler for F# is available from the F# Software Foundation.[9] F# is also a fully supported language in Visual Studio and Xamarin Studio.[11] Other tools supporting F# development include Mono, MonoDevelop, SharpDevelop, MBrace and WebSharper.[12] Plug-ins supporting F# exist for many widely used editors, most notably the Ionide extension for Atom and Visual Studio Code, and integrations for other editors such as Vim, Emacs, and Sublime Text."
                        +
                        @"  F# is member of the ML language family and originated as a .NET Framework implementation of a core of the programming language OCaml, It has also been influenced by C#, Python, Haskell, Scala, and Erlang.";
                    break;
                case "haskell":
                    languageDeinition =
                        @"Haskell ˈhæskəl' is a standardized, general-purpose purely functional programming language, with non-strict semantics and strong static typing. It is named after logician Haskell Curry. The latest standard of Haskell is Haskell 2010. As of May 2016, a group is working on the next version, Haskell 2020."
                        +
                        @"  Haskell features a type system with type inference[30] and lazy evaluation. Type classes first appeared in the Haskell programming language. Its main implementation is the Glasgow Haskell Compiler."
                        +
                        @"Haskell is based on the semantics, but not the syntax, of the language Miranda, which served to focus the efforts of the initial Haskell working group. Haskell is used widely in academia and industry.";
                    break;
                case "go":
                    languageDeinition =
                        @"Go (often referred to as Golang) is a programming language created at Google[12] in 2009 by Robert Griesemer, Rob Pike, and Ken Thompson.[11] Go is a statically typed language in the tradition of C, with memory safety, garbage collection, structural typing,[4] and CSP-style concurrent programming features added.[14] The compiler and other tools originally developed by Google are all free and open source.";
                    break;
                case "flex":
                    languageDeinition =
                        @"In computing, the FLEX language was developed by Alan Kay in the late 1960s while exploring ideas that would later evolve into the Smalltalk programming language";
                    break;
                case "jscript":
                    languageDeinition =
                        @"JScript is Microsoft's dialect of the ECMAScript standard that is used in Microsoft's Internet Explorer.
                        +
                        @   JScript is implemented as an Active Scripting engine. This means that it can be ""plugged in"" to OLE Automation applications that support Active Scripting, such as Internet Explorer, Active Server Pages, and Windows Script Host. It also means such applications can use multiple Active Scripting languages, e.g., JScript, VBScript or PerlScript.
                        +
                        @   JScript was first supported in the Internet Explorer 3.0 browser released in August 1996. Its most recent version is JScript 9.0, included in Internet Explorer 9.
                        +
                        @   JScript 10.0 is a separate dialect, also known as JScript .NET, which adds several new features from the abandoned fourth edition of the ECMAScript standard. It must be compiled for .NET Framework version 2 or version 4, but static type annotations are optional.";
                    break;
                case "perl":
                    languageDeinition =
                        @"PEARL, or Process and experiment automation realtime language, is a computer programming language designed for multitasking and real-time programming. Being a high-level language, it is fairly cross-platform. Since 1977, the language has been going under several standardization steps by the Deutsches Institut für Normung. The current version is PEARL-90, which was standardized in 1998 as DIN 66253-2."
                        +
                        @"  PEARL is not to be confused with the similarly named Perl, an entirely unrelated programming language created by Larry Wall in 1987.";
                    break;
                case "sas":
                    languageDeinition =
                        @"SAS (previously ""Statistical Analysis System"") is a software suite developed by SAS Institute for advanced analytics, multivariate analyses, business intelligence, data management, and predictive analytics."
                        +
                        @"   SAS was developed at North Carolina State University from 1966 until 1976, when SAS Institute was incorporated.SAS was further developed in the 1980s and 1990s with the addition of new statistical procedures, additional components and the introduction of JMP.A point-and - click interface was added in version 9 in 2004. A social media analytics product was added in 2010.";
                    break;
                case "smalltalk":
                    languageDeinition =
                        @"Smalltalk is an object-oriented, dynamically typed, reflective programming language. Smalltalk was created as the language to underpin the ""new world"" of computing exemplified by ""human–computer symbiosis."" It was designed and created in part for educational use, more so for constructionist learning, at the Learning Research Group (LRG) of Xerox PARC by Alan Kay, Dan Ingalls, Adele Goldberg, Ted Kaehler, Scott Wallace, and others during the 1970s."
                        +
                        @"  The language was first generally released as Smalltalk-80. Smalltalk-like languages are in continuing active development and have gathered loyal communities of users around them. ANSI Smalltalk was ratified in 1998 and represents the standard version of Smalltalk."
                        +
                        @"   Smalltalk took second place for ""most loved programming language"" in the Stack Overflow Developer Survey in 2017, but it was not among the 26 most loved programming languages of the 2018 survey";
                    break;
                case "node.js":
                    languageDeinition =
                        @"Node.js is an open-source, cross-platform JavaScript run-time environment that executes JavaScript code server-side. Historically, JavaScript was used primarily for client-side scripting, in which scripts written in JavaScript are embedded in a webpage's HTML and run client-side by a JavaScript engine in the user's web browser. Node.js lets developers use JavaScript for server-side scripting—running scripts server-side to produce dynamic web page content before the page is sent to the user's web browser. Consequently, Node.js represents a ""JavaScript everywhere"" paradigm, unifying web application development around a single programming language, rather than different languages for server side and client side scripts."
                        +
                        @"  Though.js is the conventional filename extension for JavaScript code, the name ""Node.js"" does not refer to a particular file in this context and is merely the name of the product.Node.js has an event-driven architecture capable of asynchronous I/O. These design choices aim to optimize throughput and scalability in web applications with many input/output operations, as well as for real-time Web applications (e.g., real-time communication programs and browser games)."
                        +
                        @"   The Node.js distributed development project, governed by the Node.js Foundation, is facilitated by the Linux Foundation's Collaborative Projects program."
                        +
                        @"  Corporate users of Node.js software include GoDaddy, Groupon, IBM, LinkedIn, Microsoft, Netflix, PayPal, Rakuten, SAP, Tuenti, Voxer, Walmart, and Yahoo!.";
                    break;
                case "objective-c":
                    languageDeinition =
                        @"Objective-C is a general-purpose, object-oriented programming language that adds Smalltalk-style messaging to the C programming language. It was the main programming language used by Apple for the OS X and iOS operating systems, and their respective application programming interfaces (APIs) Cocoa and Cocoa Touch prior to the introduction of Swift."
                        +
                        @"  The programming language Objective-C was originally developed in the early 1980s. It was selected as the main language used by NeXT for its NeXTSTEP operating system, from which OS X and iOS are derived. Portable Objective-C programs that do not use the Cocoa or Cocoa Touch libraries, or those using parts that may be ported or reimplemented for other systems, can also be compiled for any system supported by GNU Compiler Collection (GCC) or Clang."
                        +
                        @"  Objective-C source code 'implementation' program files usually have .m filename extensions, while Objective-C 'header/interface' files have .h extensions, the same as C header files. Objective-C++ files are denoted with a .mm file extension.";
                    break;
                case "objective c":
                    languageDeinition =
                        @"Objective-C is a general-purpose, object-oriented programming language that adds Smalltalk-style messaging to the C programming language. It was the main programming language used by Apple for the OS X and iOS operating systems, and their respective application programming interfaces (APIs) Cocoa and Cocoa Touch prior to the introduction of Swift."
                        +
                        @"  The programming language Objective-C was originally developed in the early 1980s. It was selected as the main language used by NeXT for its NeXTSTEP operating system, from which OS X and iOS are derived. Portable Objective-C programs that do not use the Cocoa or Cocoa Touch libraries, or those using parts that may be ported or reimplemented for other systems, can also be compiled for any system supported by GNU Compiler Collection (GCC) or Clang."
                        +
                        @"  Objective-C source code 'implementation' program files usually have .m filename extensions, while Objective-C 'header/interface' files have .h extensions, the same as C header files. Objective-C++ files are denoted with a .mm file extension.";
                    break;
                case "swift":
                    languageDeinition =
                        @"Swift is a general-purpose, multi-paradigm, compiled programming language developed by Apple Inc. for iOS, macOS, watchOS, tvOS, and Linux. Swift is designed to work with Apple's Cocoa and Cocoa Touch frameworks and the large body of existing Objective-C (ObjC) code written for Apple products. It is built with the open source LLVM compiler framework and has been included in Xcode since version 6. On platforms other than Linux, it uses the Objective-C runtime library which allows C, Objective-C, C++ and Swift code to run within one program."
                        +
                        @"   Apple intended Swift to support many core concepts associated with Objective-C, notably dynamic dispatch, widespread late binding, extensible programming and similar features, but ""safer"" (easier to catch software bugs); Swift has features addressing some common programming errors like null pointers and provides syntactic sugar to help avoid the pyramid of doom. Swift supports the concept of protocol extensibility, an extensibility system that can be applied to types, structs and classes, which Apple promotes as a real change in programming paradigms they term ""protocol-oriented programming"" (similar to traits)."
                        +
                        @"  Swift was introduced at Apple's 2014 Worldwide Developers Conference (WWDC). It underwent an upgrade to version 1.2 during 2014 and a more major upgrade to Swift 2 at WWDC 2015. Initially a proprietary language, version 2.2 was made open-source software under the Apache License 2.0 on December 3, 2015, for Apple's platforms and Linux."
                        +
                        @"  In March 2017, Swift made the top 10 in the monthly TIOBE index ranking of popular programming languages, and was ranked 11th at the end of 2017.";
                    break;
                default:
                    break;

            }
            await context.PostAsync(string.Format("{0}", languageDeinition));

            context.Wait(MessageReceivedAsync);
        }
    }
}